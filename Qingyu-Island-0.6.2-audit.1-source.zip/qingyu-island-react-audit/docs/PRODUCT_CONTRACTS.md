> **历史文档提示（2026-10-09，0.6.2-audit.1）**
> 以下保留原 AI Studio 导出稿的内容，不代表当前实现已验证。
> 当前执行边界与验收结果以 `00-AUDIT-STATUS.md`、`LOCAL_REVIEW_CONTRACTS.md`、
> `PIXEL_AND_CONTRACT_AUDIT_2026-10-09.md` 和 `RELEASE_READINESS.md` 为准。
> 原文中的云服务、自动到场判断、自动失约阈值、完整训练/迁移有效性或“全部通过”不能直接用于发布声明。
> 未加提示的原稿副本保存在 `audit/baseline-docs/PRODUCT_CONTRACTS.md`。

# 产品交互契约规范 (Product Interaction Contracts)

**版本**：1.0.0 (Phase B)  
**适用对象**：晴雨小岛 6岁儿童核心系统、家长端、照顾者协同端  
**核心原则**：儿童现实安全 > 对孩子诚实 > 隐私与数据最小化 > 交互契约正确 > 可验证性 > 无障碍 > 视觉一致性

---

## 1. 抱抱契约 (The Hug & Co-Presence Contract)

### 1.1 双动线分离原则
- **即时求助 (`INSTANT_HELP`)**：孩子此时此刻处于较强情绪不耐受、困惑或害怕状态，需要大人在现实中的注意力与陪伴。
- **异步想念 (`ASYNC_MISS`)**：孩子表达想念、给不在身边的家长留话、放进心愿瓶。
- **契约铁律**：两者为完全独立的业务通道与交互语义，严禁将异步留言伪造成“爸爸/妈妈马上收到并赶来”，严禁在即时求助界面混淆为无需响应的慢留言。

### 1.2 三维独立状态矩阵
不得使用单一的 boolean `isHugDelivered` 或单一状态，必须解耦为三个正交维度：

```
[通信状态 CommunicationStatus]    UNSENT -> SENDING -> SENT -> ACKNOWLEDGED / SEND_FAILED
[抚养责任 CareResponsibility]      UNASSIGNED -> ASSIGNED_SELF / ASSIGNED_OTHER / ESCALATED_FALLBACK
[物理在场 CoPresenceStatus]        NOT_PRESENT -> ON_THE_WAY -> ARRIVED_CONFIRMED / UNCONFIRMED
```

1. **通信状态 (CommunicationStatus)**：
   - `UNSENT`：尚未发出（离线暂存或初始）。
   - `SENDING`：正在发送网络报文。
   - `SENT`：已送达服务端中继。
   - `ACKNOWLEDGED`：大人的设备已接收并由大人确认“收到提醒”。
   - `SEND_FAILED`：网络或通道故障。

2. **抚养责任 (CareResponsibility)**：
   - `UNASSIGNED`：尚未有大人确认接手。
   - `ASSIGNED_SELF`：当前身边的家长接手或承诺处理。
   - `ASSIGNED_OTHER`：另一位监护人（如另一个家的家长）协同接手。
   - `ESCALATED_FALLBACK`：触发兜底联系人（如爷爷奶奶、紧急联系人）。

3. **物理在场 (CoPresenceStatus)**：
   - `NOT_PRESENT`：大人不在身边。
   - `ON_THE_WAY`：大人已确认正在走来（仅限事实触发，绝不对孩子夸大预计时长）。
   - `ARRIVED_CONFIRMED`：真人已到场（本地双人确认或本地解除）。
   - `UNCONFIRMED`：到场状态未确认。**铁律：UNCONFIRMED 绝不等于 FAILED，绝不能向孩子显示“大人失约了”或“大人没理你”！**

### 1.3 对儿童陈述语言契约
1. **只能陈述已知事实**：
   - 允许：“消息已经送给妈妈了。”
   - 允许：“爸爸在手机上点了‘我知道了’。”
   - 允许：“现在还没收到回复，我们可以先做个深呼吸，或者找身边的大人。”
2. **严禁预测性承诺**：
   - 严禁：“妈妈马上就到！”
   - 严禁：“爸爸一定会来的，别担心！”
   - 严禁：“还有 3 分钟他就进门了！”
3. **退场原则 (App Step-Back)**：
   - 当 `CoPresenceStatus === ARRIVED_CONFIRMED` 时，数字界面必须退场（淡出或显示‘大人在身边啦，小岛先去休息了’），不得用特效、新互动或连续音效抢夺孩子的注意力。

---

## 2. 围栏契约 (The Safety Fence & Boundary Precedence Contract)

### 2.1 边界绝对优先原则 (Boundary Precedence)
- 在任何思考工具（如双面币、小天平、思考侦探）启动前，**必须先执行围栏安全判定**。
- 只有当 `boundary === NONE` 时，才允许进入多视角审视、两面性思考或权衡抉择。
- 当触发明确安全边界时，**围栏逻辑具有绝对最高优先级 (Preempts all thinking tools)**。

### 2.2 绝对安全边界类型
1. `PHYSICAL_SAFETY`：身体伤害、暴力、吞食异物、攀爬高窗、触电等物理危险。
2. `PSYCHOLOGICAL_SAFETY`：严重言语恐吓、自伤念头、极度绝望。
3. `SECRECY_COERCION`：被强迫保守“不能告诉任何大人的秘密”。
4. `ADULT_RESPONSIBILITY_CROSSING`：大人强迫孩子充当间谍、打探另一方隐私、承担成人抚养纠纷、诉讼抉择或财务压力。
5. `PRIVACY_BOUNDARY`：索取私密身体部位照片、不当接触。

### 2.3 围栏处置规范
- **禁止讨论“可不可以”**：严禁在触碰红线的行为上出现双面币（寻找伤害身体的好处）或小天平（称量危险行为的得失）。
- **理解原因，不放开边界**：“我知道你现在很生气/很难过，但打人和扔东西是不可以的。”
- **对行为清晰，对人不下总判决**：不给孩子或他人贴上“坏人”、“坏孩子”的标签。
- **提供明确安全行动**：
  - 保护身体退后
  - 大声说“停下”
  - 立即走向身边的安全大人求助

---

## 3. 退后一步与脚手架契约 (Scaffolding Contract)

### 3.1 认知脚手架层级
儿童从“情绪卷入”到“认知解离/元认知”需要严密的支架推进，不可跳步：
1. **第一层：角色的想法泡泡 (`CHARACTER_THOUGHT_BUBBLE`)**  
   孩子观察第三方虚拟角色（如小熊、小兔子）头上冒出的想法，练习“想法是想法，我是我”。
2. **第二层：角色的想法可能不完全对 (`CHARACTER_MAY_BE_WRONG`)**  
   引导孩子发现小动物的想法可能猜错了、或者看漏了事实。
3. **第三层：自己过去的轻度事件 (`PAST_LIGHT_SELF_EVENT`)**  
   回顾已经平息的、非创伤性的生活小事件。
4. **第四层：自己当前的轻度事件 (`CURRENT_LIGHT_SELF_EVENT`)**  
   **受 Feature Flag 严格管控（默认关闭）**，仅当儿童在前三层有稳定表现且有成人陪同指导时才可开启。

### 3.2 支持层级 (S0 - S5)
用于量化记录儿童所需的外在协助程度：
- `S0 (Independent)`：儿童自主完成，无需外在引导。
- `S1 (Implicit Prompt)`：仅需要轻微环境反思提示。
- `S2 (Structured Scaffolding)`：需要结构化拆解卡片辅助。
- `S3 (Modeling & Partial Completion)`：需要示例引导并代为完成前置步骤。
- `S4 (Co-Regulation)`：需要成人坐在身边进行言语抚慰与同步引导。
- `S5 (Full Takeover / Paused)`：儿童出现超负荷，成人完全接管，系统温和暂停。

**铁律**：`S0-S5` 为内部研究与自适应支撑数据，**绝不得以任何形式暴露给 6 岁儿童**（不可显示分数、等级、称号或阶梯条）。

---

## 4. 迁移契约 (Transfer Contract)

### 4.1 关系结构与表面情境解耦
- 每一片内容叶子（Leaf）必须携带唯一的 `structureId`。
- 学习科学的核心目标是“思考姿态迁移”（分、通、择），而非就事论事的死记硬背。
- **训练叶 (Training Leaf)** 与 **检验叶 (Held-Out / Transfer Leaf)**：
  - 共享完全一致的内部关系结构（例如：`FEN_SINGLE_BURDEN_SPLIT`）。
  - 拥有完全不同的表面情境（例如：训练叶为“积木倒了收拾不完”，检验叶为“两个家要带的画画工具太多”）。
- **不可用“主题相似”代替“关系结构相似”**。

### 4.2 迁移有效性标准
- 只有从未经过表面情境提示、且未给予定向步骤诱导的 Held-Out 叶子，儿童自主做出的应对行为，才能被记录为迁移证据 (`Transfer Evidence`)。
- 单次点击绝不能等同于心理能力成熟。

---

## 5. 家长响应契约 (Parental Response Contract)

1. **三态隔离**：家长端在数据层严格区分“承诺接手”、“责任转交”与“已在物理身边”。
2. **无羞辱与修复语言**：若家长因现实突发情况未能及时履约，系统严禁扣分、警告、降级或谴责，只提供建设性的修复引导词（如：“跟孩子解释刚才发生了什么，抱抱他”）。
3. **熔断保护 (Circuit Breaker)**：若某项即时响应通道连续无响应，系统主动向家长建议转为预约或暂停即时功能，防止儿童反复经历“发出呼唤但落空”的无助感。
4. **双向非对抗**：两个家庭或离异父母之间的数据绝不进行对比展示、不设响应时长排行榜、不设评价对比。
